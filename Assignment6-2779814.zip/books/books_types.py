"""
XB_0082: Bestselling Books
Author: Emanuela Dumitru

Copyright (c) 2021-2022 - Eindhoven University of Technology - VU Amsterdam, The Netherlands
This software is made available under the terms of the MIT License.
"""

from typing import List
import csv
import statistics

# TODO: Add your code to tasks 1 to 5 in this file.


class Book:
    """Class Book is used to hold book object information."""
    def __init__(self, title: str, author: str, rating: float, reviews: int, price: float, years: List[int], genre: str):
        """Book class Constructor to initialize the object.

        Arg:
        title(str): Holds the title of a book object.
        author(str): Holds the author of a book object.
        rating(float): Holds the rating of a book object.
        reviews(int): Holds the amount of reviews of a book object.
        price(float): Holds the price of a book object.
        years(List[int]): Holds a list with all the years a book object was a bestseller.
        genre(str): Holds the genre of a book object."""
        self.title = title
        self.author = author
        self.rating = rating
        self.reviews = reviews
        self.price = price
        self.years = years
        self.genre = genre
        self.FICTION = "Fiction"
        self.NON_FICTION = "Non Fiction"
        self.recommended = False

    def __str__(self) -> str:
        """This function returns the string representation of the book object.

            Return:
                Str: Title of the book."""
        return self.title

    def recommend(self, rating: float, reviews: int) -> None:
        """A function that determines whether a book should be recommended or not based on the rating and reviews.

        Args:
            rating(float): The minimal rating a book should have to be recommended.
            reviews(int): The minimal amount of reviews a book should have to be recommended.

        Return:
            None"""
        if self.rating > rating:
            if self.reviews > reviews:
                self.recommended = True


class Amazon:
    """"Amazon Class that holds the amazon object information."""
    def __init__(self, bestsellers: List[Book]):
        """Amazon Class Constructor to initialize the object.
        Arg:
            bestsellers(List[Book]): A list with book that are/were bestsellers."""
        self.bestsellers = bestsellers

    def read_books_csv(self, path: str) -> None:
        """A function that opens and reads a file and then uses the information from the file to create a list with
        books.

        Args:
            path(str): The path it needs to go to the right file.

        Return:
            None"""
        books = []

        print('Reading dataset...')
        with open(path, 'r', encoding='utf8') as csvfile:
            book_reader = csv.reader(csvfile)
            for row in book_reader:
                books.append(row)

        library = dict()
        books.pop(0)
        for book in books:
            if book[0] in library.keys():
                library.get(book[0]).years.append(int(book[5]))
            else:
                year_list = [int(book[5])]
                if book[6] == "Fiction":
                    library[book[0]] = FictionBook(book[0], book[1], float(book[2]), int(book[3]), float(book[4]), year_list)
                else:
                    library[book[0]] = NonFictionBook(book[0], book[1], float(book[2]), int(book[3]), float(book[4]), year_list)

        for book in library:
            self.bestsellers.append(library[book])

    def best_year_rating(self) -> int:
        """A function that puts the ratings of all book together for each year, to determine the best rating year.

        Return:
            Int: The year with the most ratings."""
        ratings = dict()
        for book in self.bestsellers:
            for year in book.years:
                if year in ratings:
                    year_rating = ratings.get(year)
                    ratings[year] = year_rating.append(book.rating)
                else:
                    ratings[year] = [book.rating]

        highest = 0
        best_year = 0
        for year in ratings:
            year_ratings = ratings.get(year)
            year_ratings.sort()
            median = statistics.median(year_ratings)
            if median > highest:
                highest = median
                best_year = year

        return int(best_year)

    def best_year_reviews(self) -> int:
        """A function that puts the reviews of all book together for each year, to determine the best review year.

        Return:
            Int: The year with the most reviews."""
        reviews = dict()
        for book in self.bestsellers:
            for year in book.years:
                if year in reviews:
                    year_review = reviews.get(year)
                    reviews[year] = year_review.append(book.reviews)
                else:
                    reviews[year] = [book.reviews]

        best_year = 0
        highest = 0
        for year in reviews:
            year_reviews = reviews.get(year)
            year_reviews.sort()
            median = statistics.median(year_reviews)
            if median > highest:
                highest = median
                best_year = year

        return int(best_year)

    def recommend_book(self, rating: float, reviews: int) -> None:
        """A function that recommends a book based on the reviews and rating.

        Arg:
            rating(float): The minimal number of ratings a book should have to be recommended.
            reviews(int): The minimal number of reviews a book should have to be recommended.

        Return:
            None"""
        for book in self.bestsellers:
            book.recommend(int(rating), int(reviews))

    def get_recommendations(self) -> List[str]:
        """A function that returns the recommended books.

        Return:
            List[str]: A list with the book that were recommended."""

        recommendations = []
        for book in self.bestsellers:
            if book.recommended:
                recommendations.append(str(book))

        return recommendations


class FictionBook(Book):
    """FictionBook class that holds the fiction book object information."""
    def __init__(self, title: str, author: str, rating: float, reviews: int, price: float, years: List[int]):
        """FictionBook Class Constructor to initialize the object.

        Arg:
        title(str): Holds the title of a book object.
        author(str): Holds the author of a book object.
        rating(float): Holds the rating of a book object.
        reviews(int): Holds the amount of reviews of a book object.
        price(float): Holds the price of a book object.
        years(List[int]): Holds a list with all the years a book object was a bestseller."""
        super().__init__(title, author, rating, reviews, price, years, "Fiction")

    def __str__(self) -> str:
        """This function returns the string representation of the book object.

        Return:
            Str: Title, genre and years when it was a bestseller."""
        bestseller = ""
        for year in self.years:
            bestseller += str(year)
            if self.years.index(year) != -1:
                bestseller += ", "
        bestseller = bestseller[:-2]

        return f"{self.title}: {self.genre} ({bestseller})"


class NonFictionBook(Book):
    def __init__(self, title: str, author: str, rating: float, reviews: int, price: float, years: List[int]):
        """FictionBook Class Constructor to initialize the object.

        Arg:
        title(str): Holds the title of a book object.
        author(str): Holds the author of a book object.
        rating(float): Holds the rating of a book object.
        reviews(int): Holds the amount of reviews of a book object.
        price(float): Holds the price of a book object.
        years(List[int]): Holds a list with all the years a book object was a bestseller."""
        super().__init__(title, author, rating, reviews, price, years, "Non Fiction")

    def __str__(self) -> str:
        """This function returns the string representation of the book object.

        Return:
            Str: Title, genre and years when it was a bestseller."""
        bestseller = ""
        for year in self.years:
            bestseller += str(year)
            if self.years.index(year) != -1:
                bestseller += ", "
        bestseller = bestseller[:-2]

        return f"{self.title}: {self.genre} ({bestseller})"
